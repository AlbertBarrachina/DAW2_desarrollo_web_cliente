import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  Mensaje: any;
  RegisterForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl(''),
    repeat_password: new FormControl('')
  });
  constructor(public userService: UsersService){

  }
  Registrar() {
    this.userService.Registrar(this.RegisterForm.value).subscribe(
      (data) => {
        console.log(data);
        this.handleRegistrationSuccess(data);
      },
      (error) => {
        console.log(error);
        this.handleRegistrationError(error);
      }
    );  
  }

  private handleRegistrationSuccess(data: any): void {
    // Process successful response
    this.Mensaje = 'Registration correcto!';
    console.log(data);
  }

  private handleRegistrationError(error: any): void {
    // Process error response
    if (error.status === 400) {
      this.Mensaje = 'Contraseña incorecta.';
    } else if (error.status === 404) {
      this.Mensaje = 'Usuario no encontrado.';
    } else {
      this.Mensaje = 'Hubo un error durante el proceso de registro.';
    }
    console.error(error);
  }
}
