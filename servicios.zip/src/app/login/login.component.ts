import { Component} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from "src/app/services/users.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  Mensaje: any;
  LoginForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl(''),
  });

  constructor(public userService: UsersService){

  }
  Login() {
    this.userService.Login(this.LoginForm.value).subscribe(
      (data) => {
        console.log(data);
        this.handleRegistrationSuccess(data);
      },
      (error) => {
        console.log(error);
        this.handleRegistrationError(error);
      }
    );  
  }

  private handleRegistrationSuccess(data: any): void {
    // Process successful response
    this.Mensaje = 'Registration correcto!';
    console.log(data);
  }

  private handleRegistrationError(error: any): void {
    // Process error response
    if (error.status === 400) {
      this.Mensaje = 'Contraseña incorecta.';
    } else if (error.status === 404) {
      this.Mensaje = 'Usuario no encontrado.';
    } else {
      this.Mensaje = 'Hubo un error durante el proceso de registro.';
    }
    console.error(error);
  }
}
